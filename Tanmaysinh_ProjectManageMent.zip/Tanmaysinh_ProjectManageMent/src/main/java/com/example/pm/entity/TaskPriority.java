package com.example.pm.entity;

public enum TaskPriority { LOW, MEDIUM, HIGH }
