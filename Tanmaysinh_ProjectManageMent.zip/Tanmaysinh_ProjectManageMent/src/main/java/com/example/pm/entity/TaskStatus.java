package com.example.pm.entity;

public enum TaskStatus { PENDING, IN_PROGRESS, COMPLETED }
